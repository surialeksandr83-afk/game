extends CharacterBody3D

const SPEED := 4.2
const LOOK_SENS := 0.0035
const JOY_RADIUS := 95.0
var gravity := 18.0
var yaw := 0.0
var pitch := 0.0
var left_finger := -1
var right_finger := -1
var joy_origin := Vector2.ZERO
var joy_vector := Vector2.ZERO
var last_look := Vector2.ZERO
var camera: Camera3D

func _ready() -> void:
    camera = Camera3D.new()
    camera.position = Vector3(0, 0.62, 0)
    camera.fov = 78.0
    add_child(camera)
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.34
    capsule.height = 1.8
    var collision := CollisionShape3D.new()
    collision.shape = capsule
    add_child(collision)
    floor_snap_length = 0.25
    if not OS.has_feature("mobile"):
        Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _input(event: InputEvent) -> void:
    if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
        _look(event.relative)
    elif event is InputEventMouseButton and event.pressed:
        Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
    elif event is InputEventScreenTouch:
        if event.pressed:
            if event.position.x < get_viewport().get_visible_rect().size.x * 0.48 and left_finger == -1:
                left_finger = event.index
                joy_origin = event.position
                joy_vector = Vector2.ZERO
            elif right_finger == -1:
                right_finger = event.index
                last_look = event.position
        else:
            if event.index == left_finger:
                left_finger = -1
                joy_vector = Vector2.ZERO
            if event.index == right_finger:
                right_finger = -1
    elif event is InputEventScreenDrag:
        if event.index == left_finger:
            joy_vector = (event.position - joy_origin).limit_length(JOY_RADIUS) / JOY_RADIUS
        elif event.index == right_finger:
            _look(event.relative)

func _look(delta: Vector2) -> void:
    yaw -= delta.x * LOOK_SENS
    pitch = clamp(pitch - delta.y * LOOK_SENS, deg_to_rad(-82), deg_to_rad(82))
    rotation.y = yaw
    camera.rotation.x = pitch

func _physics_process(delta: float) -> void:
    if not is_on_floor():
        velocity.y -= gravity * delta
    else:
        velocity.y = -0.2
    var input_vec := joy_vector
    if not OS.has_feature("mobile"):
        input_vec = Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
    var direction := (transform.basis * Vector3(input_vec.x, 0, input_vec.y)).normalized()
    if direction:
        velocity.x = direction.x * SPEED
        velocity.z = direction.z * SPEED
    else:
        velocity.x = move_toward(velocity.x, 0, SPEED * 5 * delta)
        velocity.z = move_toward(velocity.z, 0, SPEED * 5 * delta)
    move_and_slide()
