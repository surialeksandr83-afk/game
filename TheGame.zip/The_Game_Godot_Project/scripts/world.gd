extends Node3D

const PLAYER_SCRIPT = preload("res://scripts/player.gd")

func _ready() -> void:
    randomize()
    _make_environment()
    _make_ground()
    _make_forest()
    _make_lake()
    _make_sun()
    _make_player()
    _make_hud()

func _make_environment() -> void:
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    var sky := Sky.new()
    var sky_mat := ProceduralSkyMaterial.new()
    sky_mat.sky_top_color = Color(0.18, 0.34, 0.52)
    sky_mat.sky_horizon_color = Color(0.72, 0.78, 0.72)
    sky_mat.ground_bottom_color = Color(0.10, 0.14, 0.12)
    sky_mat.ground_horizon_color = Color(0.48, 0.54, 0.48)
    sky.sky_material = sky_mat
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    env.ambient_light_energy = 0.65
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.fog_enabled = true
    env.fog_light_color = Color(0.65, 0.72, 0.68)
    env.fog_density = 0.0018
    var node := WorldEnvironment.new()
    node.environment = env
    add_child(node)

func _make_ground() -> void:
    var mesh := PlaneMesh.new()
    mesh.size = Vector2(240, 240)
    mesh.subdivide_width = 80
    mesh.subdivide_depth = 80
    var ground := MeshInstance3D.new()
    ground.mesh = mesh
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.20, 0.31, 0.18)
    mat.roughness = 1.0
    ground.material_override = mat
    ground.position.y = -0.15
    add_child(ground)

func _make_forest() -> void:
    var trunk_mesh := CylinderMesh.new()
    trunk_mesh.top_radius = 0.20
    trunk_mesh.bottom_radius = 0.30
    trunk_mesh.height = 3.0
    var leaf_mesh := SphereMesh.new()
    leaf_mesh.radius = 1.45
    leaf_mesh.height = 3.0
    var trunk_mat := StandardMaterial3D.new()
    trunk_mat.albedo_color = Color(0.25, 0.16, 0.10)
    var leaf_mat := StandardMaterial3D.new()
    leaf_mat.albedo_color = Color(0.10, 0.25, 0.14)
    leaf_mat.roughness = 0.95
    var trunks := _make_multimesh(trunk_mesh, trunk_mat, 180)
    var leaves := _make_multimesh(leaf_mesh, leaf_mat, 180)
    add_child(trunks)
    add_child(leaves)
    var rng := RandomNumberGenerator.new()
    rng.randomize()
    for i in range(180):
        var x := rng.randf_range(-90, 90)
        var z := rng.randf_range(-90, 90)
        if Vector2(x, z).length() < 10.0 or (abs(x) < 12 and z < -8 and z > -55):
            continue
        var h := rng.randf_range(0.8, 1.5)
        var t := Transform3D(Basis.IDENTITY.scaled(Vector3(h, h, h)), Vector3(x, 1.5 * h, z))
        trunks.multimesh.set_instance_transform(i, t)
        var crown := Transform3D(Basis.IDENTITY.scaled(Vector3(h, h, h)), Vector3(x, 3.5 * h, z))
        leaves.multimesh.set_instance_transform(i, crown)

func _make_multimesh(mesh: Mesh, mat: Material, count: int) -> MultiMeshInstance3D:
    var mm := MultiMesh.new()
    mm.transform_format = MultiMesh.TRANSFORM_3D
    mm.mesh = mesh
    mm.instance_count = count
    var inst := MultiMeshInstance3D.new()
    inst.multimesh = mm
    inst.material_override = mat
    return inst

func _make_lake() -> void:
    var lake := MeshInstance3D.new()
    var mesh := PlaneMesh.new()
    mesh.size = Vector2(24, 34)
    lake.mesh = mesh
    lake.position = Vector3(0, -0.05, -35)
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.12, 0.30, 0.36, 0.88)
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.roughness = 0.18
    mat.metallic = 0.18
    lake.material_override = mat
    add_child(lake)

func _make_sun() -> void:
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48, -28, 0)
    sun.light_energy = 1.15
    sun.shadow_enabled = true
    sun.directional_shadow_max_distance = 55.0
    add_child(sun)

func _make_player() -> void:
    var player := CharacterBody3D.new()
    player.set_script(PLAYER_SCRIPT)
    player.name = "Player"
    player.position = Vector3(0, 1.0, 8)
    add_child(player)

func _make_hud() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var title := Label.new()
    title.text = "THE GAME   •   WALK"
    title.position = Vector2(22, 18)
    title.add_theme_font_size_override("font_size", 20)
    title.add_theme_color_override("font_color", Color(1, 1, 1, 0.85))
    layer.add_child(title)
    var hint := Label.new()
    hint.text = "Левый палец — движение   •   правый — обзор"
    hint.position = Vector2(22, 48)
    hint.add_theme_font_size_override("font_size", 14)
    hint.add_theme_color_override("font_color", Color(1, 1, 1, 0.72))
    layer.add_child(hint)
