# The Game — Godot starter project

A small first-person walking prototype for Godot 4.3+.

## Open
1. Install Godot 4.3 or newer.
2. Import `project.godot`.
3. Press F6/F5 to run.

## Controls
- Desktop: WASD / arrow keys + mouse look (click to capture mouse; Esc releases it).
- Touch: left side drag moves; right side drag looks around.

## Android export
Install Godot export templates and Android build prerequisites, configure the Android SDK/JDK in Editor Settings, then use Project > Export > Android.
Recommended first test: Compatibility renderer, 1280x720 viewport, portrait/landscape can be adjusted in export settings.

This is a starter prototype, not a finished commercial game. It uses simple procedural meshes and no external assets.
